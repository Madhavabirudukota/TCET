package com.TCET;

public class Question5 {
	//function to move all zeros to end 
	public static void moveZeroEnd(int[]crates)
	{
		int N=crates.length;
		int i=0;//to track the position element
		
		//move elements to front
		for (int j=0;j<N;j++)
		{
			if(crates[j]!=0)
			{
				crates[i]=crates[j];
				i++;
			}
		}
		//zeros to last position
		while(i<N)
		{
			crates[i]=0;
			i++;
		}
	}

	public static void main(String[] args) {
		
		int[] crates={1,3,0,5,0,12,0};
		System.out.println("Before moving zeros:");
		printArray(crates);
		moveZeroEnd(crates);
		System.out.println("After moving zeros");
		printArray(crates);
	}

	public static void printArray(int[] arr) {
		for(int i:arr)
		{
			System.out.print(i+" ");
		}
		System.out.println();	
	}
}
