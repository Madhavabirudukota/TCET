package com.TCET;
import java.util.HashMap;
import java.util.Map;
public class Question3 {

	public static void main(String[] args) {
		// input String 
		String input="This is a test string.This string is for testing";
		String[] words=input.toLowerCase().split("\\s+|\\.|\\,");
		Map<String ,Integer>wordCount=new HashMap<>();
		//count each word
		for(String word :words)
		{
			if (!word.isEmpty())
			{
				wordCount.put(word,wordCount.getOrDefault(word,0)+1);
			}
		}
 for (Map.Entry<String,Integer>entry:wordCount.entrySet()) {
	 System.out.println(entry.getKey()+ ":" +entry.getValue());
	 }
 }
}
