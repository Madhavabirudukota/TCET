package com.TCET;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;
public class Question4 {

	public static void main(String[] args) {
		//list of integers
		List<Integer> numbers=Arrays.asList(11,22,35,40,5,6,71,80);
		//to filter the even numbers
		List <Integer> evenNumber=numbers.stream().filter(n->n%2==0).collect(Collectors.toList());
		//printing even numbers
		System.out.println("even Numbers are "+evenNumber);
	}
}
