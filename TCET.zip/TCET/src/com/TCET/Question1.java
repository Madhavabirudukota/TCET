package com.TCET;
//Functional interface
@FunctionalInterface
interface Sayable{
String say(String message);
}
public class Question1 {

	public static void main(String[] args) {
		//lambda expression that implements the say method
		Sayable sayable=(message)->"hello,"+message;
		//using lambda expression
		String greeting=sayable.say("madhava");
		System.out.println(greeting);
		
	}

}